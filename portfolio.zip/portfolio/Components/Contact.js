import React from 'react';


const Contact = () => {

return( <div> 

  <h3>Want to collaborate? Drop me an offer at kristina.bietina.de@gmail.com</h3>

</div>
)

}

export default Contact;