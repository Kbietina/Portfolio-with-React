import React from 'react';


const RightSide = () => {

return( <div> 

    <h1>designer</h1>
<p>UI/UX designer with passion of designing beuatiful and native user experiences.</p>


<div>

<ul>
Tools: 

<li>  Adobe Photoshop   </li>
<li>  Adobe Illustrator  </li>
<li>  Adobe Indesign  </li>
<li>  Figma </li>
<li>  Sketch </li>


</ul>



</div>

</div>
)

}

export default RightSide;