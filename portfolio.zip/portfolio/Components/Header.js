import React from 'react';
import logo from './public/logo.png';

/*
const logo = require('./public/icons8-twitter-50.png');
const linkedin = require('./public/icons8-linkedin-50.png');
const github = require('./public/icons8-github-50.png');
const behance = require('./portfolio/public/icons8-behance-50.png');
const twitter = require('./public/icons8-circled-k-100.png');

*/

const Header = () => {

return( <div> 
Some text
    
<div class = "logo-portfolio">  <img src = {logo} name = "logo"/>    </div>
<div class = "linkedin"> <img src = {linkedin} name = "linkedin"/>    </div>
<div class = "github">  <img src = {github} name = "github"/>    </div>
<div class = "behance">   <img src = {behance} name = "behance"/>   </div>
<div class = "twitter"> <img src = {twitter} name = "twitter"/>     </div>


</div>
)

}

export default Header;