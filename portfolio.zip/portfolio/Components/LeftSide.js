import React from 'react';


const LeftSide = () => {

return( <div> 

    <h1>&lt coder &lt</h1>
<p>Front-end developer who focuses on writing clean, elegant and efficient code.</p>


<div>

<ul>
Stack: 

<li>  HTML5, CSS/SASS   </li>
<li>  Javascript </li>
<li>  React, React Native  </li>
<li>  Node.js, Express.jss</li>
<li>  MongoDB </li>
<li>  SQL </li>



</ul>



</div>

</div>
)

}

export default LeftSide;